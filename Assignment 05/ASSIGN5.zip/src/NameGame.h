#ifndef NAMEGAME_H
#define NAMEGAME_H

namespace arcade {
    void playNameGuessingGame();
}

#endif
