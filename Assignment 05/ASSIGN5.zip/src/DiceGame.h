#ifndef DICEGAME_H
#define DICEGAME_H

namespace arcade {
    void playDiceGame();
}

#endif
