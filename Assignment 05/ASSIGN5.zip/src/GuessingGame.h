#ifndef GUESSINGGAME_H
#define GUESSINGGAME_H

namespace arcade {
    void playGuessingGame();
}

#endif
