#ifndef CREDITS_H
#define CREDITS_H

namespace arcade {

    void showCredits();

}

#endif
