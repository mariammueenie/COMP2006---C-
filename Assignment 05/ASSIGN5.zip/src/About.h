#ifndef ABOUT_H
#define ABOUT_H

namespace arcade {

    void showAbout();

}

#endif
